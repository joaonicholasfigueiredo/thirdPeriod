/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package senai.com.br.projetofabrica;

import javax.swing.JOptionPane;
import senai.com.br.model.*;
import senai.com.br.factory.*;

/**
 *
 * @author Nicholas
 */
public class ProjetoFabricaAnimal {
    
    public static void saidaDeDados(Animal objeto){
        String saida = "Nome do Animal: " + objeto.getNomeAnimal() + "\n";
        saida += "Quantidade de Presas: " + objeto.getQtdPresas() + "\n";
        saida += "Quantidade de Patas: " + objeto.getQtdPatas() + "\n";
        saida += "Tipo de Pelagem: " + objeto.getPelagem() + "\n";
        saida += "Alimentação: " + objeto.getAlimentacao() + "\n";
        saida += "Familia: " + objeto.getFamilia() + "\n";
        saida += "Habitat: " + objeto.getHabitat();
        JOptionPane.showMessageDialog(null, saida);
    }
    
    public static void main(String[] args) {
        boolean control = true;
        Object[] opcoes = {"COBRA", "COELHO", "MACACO"};
        Object tipoDoAnimal;
        Animal obj = null;
        do{
            tipoDoAnimal = JOptionPane.showInputDialog(null,
                    "Deseja Finalizar o programa?",
                    "Finalização",
                    JOptionPane.PLAIN_MESSAGE,
                    null,opcoes,"COBRA");
            obj = FabricaAnimais.getAnimal(tipoDoAnimal.toString());
            saidaDeDados(obj);
        }while(control);
    }
    
}
