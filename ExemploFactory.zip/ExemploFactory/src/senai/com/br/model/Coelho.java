/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package senai.com.br.model;

/**
 *
 * @author Nicholas
 */
public class Coelho extends Animal{
    
    public Coelho(String nomeAnimal, int qtdPresas, int qtdPatas, String pelagem, String alimentacao, String familia, String habitat){
        super(nomeAnimal, qtdPresas, qtdPatas, pelagem, alimentacao, familia, habitat);
    }

    @Override
    public String descricao() {
        return ("Animal pacífico que serve de estimação e é o simbolo da páscoa para as crianças e da fertilidade para os adultos");
    }
    
}
