/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package senai.com.br.model;

/**
 *
 * @author Nicholas
 */
public class Cobra extends Animal{
    
    public Cobra(String nomeAnimal, int qtdPresas, int qtdPatas, String pelagem, String alimentacao, String familia, String habitat){
        super(nomeAnimal, qtdPresas, qtdPatas, pelagem, alimentacao, familia, habitat);
    }

    @Override
    public String descricao() {
        return ("Animal reptil sem patas");
    }
    
}
