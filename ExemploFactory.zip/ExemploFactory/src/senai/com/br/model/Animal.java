/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package senai.com.br.model;

/**
 *
 * @author Nicholas
 */
public abstract class Animal {

    //Atributos
    private String nomeAnimal;
    private int qtdPresas;
    private int qtdPatas;
    private String pelagem;
    private String alimentacao;
    private String familia;
    private String habitat;

    //metodos    
    public abstract String descricao();

    public Animal(String nomeAnimal, int qtdPresas, int qtdPatas, String pelagem, String alimentacao, String familia, String habitat) {
        this.nomeAnimal = nomeAnimal;
        this.qtdPresas = qtdPresas;
        this.qtdPatas = qtdPatas;
        this.pelagem = pelagem;
        this.alimentacao = alimentacao;
        this.familia = familia;
        this.habitat = habitat;
    }
    
    public String getNomeAnimal(){
        return nomeAnimal;
    }
    
    public void setNomeAnimal(){
        this.nomeAnimal = nomeAnimal;
    }
    

    public int getQtdPresas() {
        return qtdPresas;
    }

    public void setQtdPresas(int qtdPresas) {
        this.qtdPresas = qtdPresas;
    }

    public int getQtdPatas() {
        return qtdPatas;
    }

    public void setQtdPatas(int qtdPatas) {
        this.qtdPatas = qtdPatas;
    }

    public String getPelagem() {
        return pelagem;
    }

    public void setPelagem(String pelagem) {
        this.pelagem = pelagem;
    }

    public String getAlimentacao() {
        return alimentacao;
    }

    public void setAlimentacao(String alimentacao) {
        this.alimentacao = alimentacao;
    }

    public String getFamilia() {
        return familia;
    }

    public void setFamilia(String familia) {
        this.familia = familia;
    }
    
    
    public String getHabitat(){
        return habitat;
    }
    
    public void setHabitat(String habitat){
        this.habitat = habitat;
    }
}
