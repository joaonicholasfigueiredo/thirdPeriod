/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package senai.com.br.factory;
import senai.com.br.model.*;
/**
 *
 * @author Nicholas
 */
public class FabricaAnimais {
    
    public enum Animais{
        MACACO, COBRA, COELHO;
    }
    
    public static Animal getAnimal(String tipoDoAnimal){
        Animais tipoAnimal = Animais.valueOf(tipoDoAnimal);
        switch(tipoAnimal){
            case MACACO:
                return new Macaco("Macaco",32,2,"Pelo com tonalidades diferentes depenedndo da especie", "Principalmente frutas","Reino Animalis, familia dos Cebídeos","Predominantemente em florestas tropicais e equatoriais");
                
            case COBRA:
                return new Cobra("Cobra",4,9,"Escamas com tonalidades diferentes dependendo da especie", "Roedores e animais de pequeno porte","Existem mais de 10 tipos, podendo citar: Viperidae e Elapidae que são peçonhentas", "Depenedndo da especie, climas bem úmidos ou secos");
           
            case COELHO:
                return new Coelho("Coelho",6,4,"Chincila, himalaia, aguti e albina","Frutas e sementes","Familia Leporidae","Areas secas próximo ao nível mar, como bosques. Ou em area domiciliar");
            
            
            
            default:
                return null;
        }
                
    }
    
}
